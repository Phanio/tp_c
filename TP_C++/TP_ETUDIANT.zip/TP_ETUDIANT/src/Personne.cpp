#include "Personne.h"
#include <string>
Personne::Personne()
{

}

Personne::Personne(std::string n, std::string p)
{
    nom = n;
    prenom = p;
}






