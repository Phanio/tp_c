#include "Circle.h"

Circle::Circle()
{
    //ctor
}
