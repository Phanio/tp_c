#include <iostream>

using namespace std;
template<typename T>
int binarySearch(const T arrays[], T key, int sizeArray);
int main()
{
    int sizeArray=6, key1 =12 ;
    int arr1[] = {3,5,7,12,33,88};
    double arr2[] = {3,5,7.5,12.5,37.8,56.9};
    double key2 = 7.8;
    string arr3[] = {"me", "you", "name", "open", "size array", "title of the book"};
    string key3 = "open";

    int keyIndex1 = binarySearch(arr1, key1,sizeArray);
    if(keyIndex1!=-1)
    {
        cout<<key1<< " is at the index "<< keyIndex1 << endl;
    }
    else
    {
        cout<<key1<< " is not in the array "  << endl;
    }

    int keyIndex2 = binarySearch(arr2, key2,sizeArray);
    if(keyIndex2!=-1)
    {
        cout<<key2<< " is at the index "<< keyIndex2 << endl;
    }
    else
    {
        cout<<key2<< " is not in the array "  << endl;
    }

    int keyIndex3 = binarySearch(arr3, key3,sizeArray);
    if(keyIndex3!=-1)
    {
        cout<<key3<< " is at the index "<< keyIndex3 << endl;
    }
    else
    {
        cout<<key3<< " is not in the array "  << endl;
    }
    return 0;
}

template<typename T>
int binarySearch(const T arrays[], T key, int sizeArray)
{
    int firstIndex = 0;
    int lastIndex = sizeArray -1;
    int middleIndex = (lastIndex + firstIndex)/2;
    while(firstIndex <= lastIndex)
    {
        if(arrays[middleIndex]> key)
        {
            lastIndex = middleIndex -1;
        }
        else if(arrays[middleIndex]== key)
        {
            return middleIndex;
        }
        else
        {
            firstIndex = middleIndex+1;
        }
        middleIndex = (lastIndex+firstIndex)/2;
    }
    return -1;
}
