#include "Examen.h"

Examen::Examen()
{
}

Examen::Examen(double nte)
{
    note = nte;
}
